<?php
// Foutmelding ophalen als die er is
$fout = isset($_GET['fout']) ? htmlspecialchars(urldecode($_GET['fout'])) : '';
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bugatti Chiron Super Sport — Wealth Creators</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body class="paginatop">
  <nav class="nav">
    <a href="../index.html" class="nav__logo">WEALTH CREATORS</a>
    <ul class="nav__links">
      <li><a href="../index.html">Home</a></li>
      <li><a href="overzicht.html" class="actief">Producten</a></li>
      <li><a href="berichten.php">Berichten</a></li>
    </ul>
    <button class="nav__hamburger" aria-label="Menu openen"><span></span><span></span><span></span></button>
  </nav>
  <div class="nav__offscreen">
    <a href="../index.html">Home</a>
    <a href="overzicht.html">Producten</a>
    <a href="berichten.php">Berichten</a>
  </div>
  <div class="showcase">
    <div class="showcase__foto">
      <img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1200&q=85" alt="Bugatti Chiron Super Sport">
    </div>
    <div class="showcase__info">
      <p class="showcase__categorie">Automobiel</p>
      <h1 class="showcase__naam">Bugatti Chiron<br><em>Super Sport</em></h1>
      <p class="showcase__prijs">Vraagprijs: € 3.200.000 &mdash; Minimumbod: € 3.000.000</p>
      <p class="showcase__beschrijving">De Bugatti Chiron Super Sport is het absolute toppunt van automobieltechniek. Met een 8.0-liter W16 motor levert dit kunstwerk 1.600 pk en haalt een topsnelheid van 440 km/u. Slechts 30 exemplaren zijn geproduceerd.</p>
      <div class="showcase__specs">
        <div><p class="spec__label">Vermogen</p><p class="spec__waarde">1.600 pk</p></div>
        <div><p class="spec__label">Topsnelheid</p><p class="spec__waarde">440 km/u</p></div>
        <div><p class="spec__label">0 — 100 km/u</p><p class="spec__waarde">2,4 seconden</p></div>
        <div><p class="spec__label">Bouwjaar</p><p class="spec__waarde">2023</p></div>
      </div>

      <?php if ($fout !== ''): ?>
        <p style="color:#c0392b; border:1px solid #c0392b; padding:12px 16px; margin-bottom:16px; font-size:14px;"><?= $fout ?></p>
      <?php endif; ?>

      <form class="formulier" action="bod_verwerken.php" method="POST">
        <input type="hidden" name="product" value="Bugatti Chiron Super Sport">
        <input type="hidden" name="categorie" value="automobiel">
        <input type="hidden" name="min_bod" value="3000000">
        <input type="hidden" name="terug" value="bugatti.php">
        <div class="formulier__rij">
          <div class="formulier__groep">
            <label class="formulier__label" for="naam">Naam</label>
            <input class="formulier__veld" type="text" id="naam" name="naam" placeholder="Uw naam" required>
          </div>
          <div class="formulier__groep">
            <label class="formulier__label" for="email">E-mail</label>
            <input class="formulier__veld" type="email" id="email" name="email" placeholder="u@domein.nl" required>
          </div>
        </div>
        <div class="formulier__groep">
          <label class="formulier__label" for="bericht">Bericht</label>
          <textarea class="formulier__veld" id="bericht" name="bericht" placeholder="Stel uw vraag of laat een opmerking achter..." required></textarea>
        </div>
        <div class="formulier__groep">
          <label class="formulier__label" for="bod">Uw bod (minimaal € 3.000.000)</label>
          <input class="formulier__veld" type="number" id="bod" name="bod" placeholder="3000000" min="3000000" required>
        </div>
        <button type="submit" class="knop" style="border:none;cursor:pointer;">Verstuur bod</button>
      </form>
    </div>
  </div>

  <section class="sectie sectie--donker">
    <div class="sectie__hoofd"><h2 class="sectie__titel">Andere producten</h2><a href="overzicht.html" class="sectie__link">Alle producten</a></div>
    <div class="product-grid">
      <a href="lamborghini.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1525609004556-c46c7d6cf023?w=1200&q=85" alt="Lamborghini Aventador SVJ"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Automobiel</p><h3 class="product-kaart__naam">Lamborghini Aventador SVJ</h3><p class="product-kaart__prijs">Vanaf € 2.400.000</p></div></a>
      <a href="villa.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200&q=85" alt="Villa Côte d'Azur"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Vastgoed</p><h3 class="product-kaart__naam">Villa Côte d'Azur</h3><p class="product-kaart__prijs">Vanaf € 18.500.000</p></div></a>
      <a href="rolex.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=1200&q=85" alt="Rolex Daytona Platina"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Horloge</p><h3 class="product-kaart__naam">Rolex Daytona Platina</h3><p class="product-kaart__prijs">Vanaf € 320.000</p></div></a>
    </div>
  </section>
  <footer class="footer">
    <div><p class="footer__logo">WEALTH CREATORS</p><p class="footer__omschrijving">De exclusieve marktplaats voor diegenen die alleen het allerbeste accepteren.</p></div>
    <div><p class="footer__koptekst">Navigatie</p><ul class="footer__lijst"><li><a href="../index.html">Home</a></li><li><a href="overzicht.html">Producten</a></li><li><a href="berichten.php">Berichten</a></li></ul></div>
    <div><p class="footer__koptekst">Categorieën</p><ul class="footer__lijst"><li><a href="overzicht.html">Automobiel</a></li><li><a href="overzicht.html">Vastgoed</a></li><li><a href="overzicht.html">Horloges</a></li><li><a href="overzicht.html">Boten</a></li></ul></div>
  </footer>
  <div class="footer__onder"><p class="footer__copy">2026 Wealth Creators. Alle rechten voorbehouden.</p><p class="footer__copy">Ontworpen door Team D1B</p></div>
  <script src="../js/main.js"></script>
</body>
</html>