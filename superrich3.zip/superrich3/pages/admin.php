<?php
session_start();

// Wachtwoord controleren
$wachtwoord = 'superrich123';

if (isset($_POST['ww'])) {
    if ($_POST['ww'] === $wachtwoord) {
        $_SESSION['admin'] = true;
    } else {
        $fout_login = 'Ongeldig wachtwoord.';
    }
}

if (isset($_GET['uitloggen'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Nog niet ingelogd: loginformulier tonen
if (empty($_SESSION['admin'])):
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login — Wealth Creators</title>
  <link rel="stylesheet" href="../css/style.css">
  <style>
    .login-wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    .login-box { width: 100%; max-width: 380px; padding: 48px; background: var(--donker); border: 1px solid var(--rand); }
    .login-titel { font-family: var(--font-kop); font-size: 32px; color: var(--wit); margin-bottom: 8px; }
    .login-sub { font-size: 13px; color: var(--grijs); margin-bottom: 32px; }
    .login-fout { color: #c0392b; font-size: 13px; border: 1px solid #c0392b; padding: 10px 14px; margin-bottom: 16px; }
  </style>
</head>
<body>
  <div class="login-wrap">
    <div class="login-box">
      <p class="nav__logo" style="margin-bottom:24px">WEALTH CREATORS</p>
      <h1 class="login-titel">Admin</h1>
      <p class="login-sub">Vul het wachtwoord in om verder te gaan.</p>
      <?php if (!empty($fout_login)): ?>
        <p class="login-fout"><?= $fout_login ?></p>
      <?php endif; ?>
      <form method="POST" class="formulier">
        <div class="formulier__groep">
          <label class="formulier__label" for="ww">Wachtwoord</label>
          <input class="formulier__veld" type="password" id="ww" name="ww" required autofocus>
        </div>
        <button type="submit" class="knop" style="margin-top:8px;border:none;cursor:pointer;width:100%;">Inloggen</button>
      </form>
    </div>
  </div>
</body>
</html>
<?php
// Stop hier — laat de rest van de pagina niet zien
return;
endif;

// Ingelogd: data ophalen
require_once '../includes/db.php';

// Berichten per categorie ophalen
$categorieeen = ['automobiel', 'vastgoed', 'horloge', 'boot', 'helikopter', 'sieraad', 'overig'];
$labels = [
    'automobiel' => 'Automobiel',
    'vastgoed'   => 'Vastgoed',
    'horloge'    => 'Horloges',
    'boot'       => 'Boten',
    'helikopter' => 'Helikopters',
    'sieraad'    => 'Sieraden',
    'overig'     => 'Overig',
];

$alle_berichten = [];
foreach ($categorieeen as $cat) {
    $stmt = $pdo->prepare('SELECT * FROM berichten WHERE categorie = :cat ORDER BY datum DESC');
    $stmt->execute([':cat' => $cat]);
    $rijen = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!empty($rijen)) {
        $alle_berichten[$cat] = $rijen;
    }
}

$totaal = $pdo->query('SELECT COUNT(*) FROM berichten')->fetchColumn();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin — Wealth Creators</title>
  <link rel="stylesheet" href="../css/style.css">
  <style>
    .admin-tabel { width: 100%; border-collapse: collapse; margin-bottom: 48px; }
    .admin-tabel th { text-align: left; font-size: 11px; letter-spacing: .12em; text-transform: uppercase; color: var(--goud); padding: 12px 16px; border-bottom: 1px solid var(--goud); }
    .admin-tabel td { padding: 14px 16px; border-bottom: 1px solid var(--rand); font-size: 14px; color: var(--grijs); vertical-align: top; }
    .admin-tabel tr:hover td { background: rgba(255,255,255,.03); }
    .admin-tabel .naam { color: var(--wit); font-weight: 500; }
    .admin-tabel .bod  { color: var(--goud-licht); font-family: var(--font-kop); font-size: 18px; }
    .admin-tabel .geen-bod { color: var(--grijs); font-style: italic; font-size: 13px; }
    .cat-kop { font-family: var(--font-kop); font-size: 28px; color: var(--wit); margin: 48px 0 16px; padding-bottom: 12px; border-bottom: 1px solid var(--rand); }
    .cat-kop:first-of-type { margin-top: 0; }
    .teller { font-size: 13px; color: var(--grijs); margin-top: 8px; }
    .uitloggen { font-size: 12px; letter-spacing: .1em; text-transform: uppercase; color: var(--grijs); border: 1px solid var(--rand); padding: 8px 16px; transition: color .2s, border-color .2s; }
    .uitloggen:hover { color: var(--goud); border-color: var(--goud); }
  </style>
</head>
<body class="paginatop">
  <nav class="nav">
    <a href="../index.html" class="nav__logo">WEALTH CREATORS</a>
    <ul class="nav__links">
      <li><a href="../index.html">Home</a></li>
      <li><a href="overzicht.html">Producten</a></li>
      <li><a href="berichten.php">Berichten</a></li>
      <li><a href="admin.php" class="actief">Admin</a></li>
    </ul>
    <button class="nav__hamburger" aria-label="Menu openen"><span></span><span></span><span></span></button>
  </nav>
  <div class="nav__offscreen">
    <a href="../index.html">Home</a>
    <a href="overzicht.html">Producten</a>
    <a href="berichten.php">Berichten</a>
    <a href="admin.php">Admin</a>
  </div>

  <div class="pagina-kop">
    <p class="pagina-kop__label">Beheer</p>
    <h1 class="pagina-kop__titel">Alle biedingen</h1>
    <p class="teller"><?= $totaal ?> bericht(en) ontvangen &nbsp;&mdash;&nbsp; <a href="admin.php?uitloggen=1" class="uitloggen">Uitloggen</a></p>
  </div>

  <section class="sectie">
    <?php if (empty($alle_berichten)): ?>
      <p style="color:var(--grijs)">Er zijn nog geen biedingen ontvangen.</p>
    <?php else: ?>

      <?php foreach ($alle_berichten as $cat => $rijen): ?>
        <h2 class="cat-kop"><?= $labels[$cat] ?></h2>
        <table class="admin-tabel">
          <thead>
            <tr>
              <th>#</th>
              <th>Datum</th>
              <th>Naam</th>
              <th>E-mail</th>
              <th>Product</th>
              <th>Bericht</th>
              <th>Bod</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rijen as $b): ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td><?= date('d-m-Y H:i', strtotime($b['datum'])) ?></td>
                <td class="naam"><?= $b['naam'] ?></td>
                <td><?= $b['email'] ?></td>
                <td><?= $b['product'] ?></td>
                <td><?= $b['bericht'] ?></td>
                <td>
                  <?php if ($b['bod'] !== null): ?>
                    <span class="bod">€ <?= number_format($b['bod'], 0, ',', '.') ?></span>
                  <?php else: ?>
                    <span class="geen-bod">Geen bod</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endforeach; ?>

    <?php endif; ?>
  </section>

  <footer class="footer">
    <div><p class="footer__logo">WEALTH CREATORS</p><p class="footer__omschrijving">De exclusieve marktplaats voor diegenen die alleen het allerbeste accepteren.</p></div>
    <div><p class="footer__koptekst">Navigatie</p><ul class="footer__lijst"><li><a href="../index.html">Home</a></li><li><a href="overzicht.html">Producten</a></li><li><a href="berichten.php">Berichten</a></li></ul></div>
    <div><p class="footer__koptekst">Categorieën</p><ul class="footer__lijst"><li><a href="overzicht.html">Automobiel</a></li><li><a href="overzicht.html">Vastgoed</a></li><li><a href="overzicht.html">Horloges</a></li><li><a href="overzicht.html">Boten</a></li></ul></div>
  </footer>
  <div class="footer__onder"><p class="footer__copy">2026 Wealth Creators. Alle rechten voorbehouden.</p><p class="footer__copy">Ontworpen door Team D1B</p></div>
  <script src="../js/main.js"></script>
</body>
</html>
