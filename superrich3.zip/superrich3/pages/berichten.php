<?php
require_once '../includes/db.php';

// Alleen naam, bericht, product en datum — GEEN bod
$stmt = $pdo->query('SELECT naam, bericht, product, datum FROM berichten ORDER BY datum DESC');
$berichten = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Berichten — Wealth Creators</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body class="paginatop">
  <nav class="nav">
    <a href="../index.html" class="nav__logo">WEALTH CREATORS</a>
    <ul class="nav__links">
      <li><a href="../index.html">Home</a></li>
      <li><a href="overzicht.html">Producten</a></li>
      <li><a href="berichten.php" class="actief">Berichten</a></li>
    </ul>
    <button class="nav__hamburger" aria-label="Menu openen"><span></span><span></span><span></span></button>
  </nav>
  <div class="nav__offscreen">
    <a href="../index.html">Home</a>
    <a href="overzicht.html">Producten</a>
    <a href="berichten.php">Berichten</a>
  </div>

  <div class="pagina-kop">
    <p class="pagina-kop__label">Overzicht</p>
    <h1 class="pagina-kop__titel">Berichten</h1>
  </div>

  <section class="sectie">
    <?php if (isset($_GET['verzonden'])): ?>
      <p style="color:var(--goud);margin-bottom:32px;font-size:15px;border:1px solid var(--goud);padding:14px 20px;">
        Uw bericht is succesvol verstuurd.
      </p>
    <?php endif; ?>

    <?php if (empty($berichten)): ?>
      <p style="color:var(--grijs);font-size:15px;">Er zijn nog geen berichten ontvangen.</p>
    <?php else: ?>
      <div class="berichten-lijst">
        <?php foreach ($berichten as $b): ?>
          <div class="bericht-rij">
            <div>
              <p class="bericht__afzender"><?= $b['naam'] ?></p>
              <p class="bericht__tekst"><?= $b['bericht'] ?></p>
              <p class="bericht__product"><?= $b['product'] ?></p>
            </div>
            <div class="bericht__meta">
              <p class="bericht__datum"><?= date('j F Y', strtotime($b['datum'])) ?></p>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <footer class="footer">
    <div><p class="footer__logo">WEALTH CREATORS</p><p class="footer__omschrijving">De exclusieve marktplaats voor diegenen die alleen het allerbeste accepteren.</p></div>
    <div><p class="footer__koptekst">Navigatie</p><ul class="footer__lijst"><li><a href="../index.html">Home</a></li><li><a href="overzicht.html">Producten</a></li><li><a href="berichten.php">Berichten</a></li></ul></div>
    <div><p class="footer__koptekst">Categorieën</p><ul class="footer__lijst"><li><a href="overzicht.html">Automobiel</a></li><li><a href="overzicht.html">Vastgoed</a></li><li><a href="overzicht.html">Horloges</a></li><li><a href="overzicht.html">Boten</a></li></ul></div>
  </footer>
  <div class="footer__onder"><p class="footer__copy">2026 Wealth Creators. Alle rechten voorbehouden.</p><p class="footer__copy">Ontworpen door Team D1B</p></div>
  <script src="../js/main.js"></script>
</body>
</html>
