<?php
ob_start();

$product   = strip_tags(htmlspecialchars(trim($_POST['product'] ?? '')));
$categorie = strip_tags(htmlspecialchars(trim($_POST['categorie'] ?? 'overig')));
$naam      = strip_tags(htmlspecialchars(trim($_POST['naam'] ?? '')));
$email     = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$bericht   = strip_tags(htmlspecialchars(trim($_POST['bericht'] ?? '')));
$bod_raw   = trim($_POST['bod'] ?? '');
$min_bod   = (int) ($_POST['min_bod'] ?? 0);
$terug     = $_POST['terug'] ?? '../index.html';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.html');
    exit;
}

$errors = [];

if (empty($naam)) {
    $errors[] = 'Vul uw naam in.';
}
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Vul een geldig e-mailadres in.';
}
if (empty($bericht)) {
    $errors[] = 'Vul een bericht in.';
}

$bod = null;
if ($bod_raw !== '') {
    if (!is_numeric($bod_raw)) {
        $errors[] = 'Het bod moet een getal zijn.';
    } elseif ((float) $bod_raw < $min_bod) {
        $errors[] = 'Uw bod is lager dan het minimumbod van € ' . number_format($min_bod, 0, ',', '.');
    } else {
        $bod = (float) $bod_raw;
    }
}

if (!empty($errors)) {
    $fout_string = urlencode(implode(' | ', $errors));
    ob_end_clean();
    header('Location: ' . $terug . '?fout=' . $fout_string);
    exit;
}

try {
    require_once '../includes/db.php';

    $sql = 'INSERT INTO berichten (product, categorie, naam, email, bericht, bod) VALUES (:product, :categorie, :naam, :email, :bericht, :bod)';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':product'   => $product,
        ':categorie' => $categorie,
        ':naam'      => $naam,
        ':email'     => $email,
        ':bericht'   => $bericht,
        ':bod'       => $bod,
    ]);

    ob_end_clean();
    header('Location: berichten.php?verzonden=1');
    exit;

} catch (Exception $e) {
    $fout = urlencode('Databasefout: kon het bod niet opslaan. Probeer het opnieuw.');
    ob_end_clean();
    header('Location: ' . $terug . '?fout=' . $fout);
    exit;
}
