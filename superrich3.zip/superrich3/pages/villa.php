<?php
// Foutmelding ophalen als die er is
$fout = isset($_GET['fout']) ? htmlspecialchars(urldecode($_GET['fout'])) : '';
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Villa Côte d'Azur — Wealth Creators</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body class="paginatop">
  <nav class="nav">
    <a href="../index.html" class="nav__logo">WEALTH CREATORS</a>
    <ul class="nav__links">
      <li><a href="../index.html">Home</a></li>
      <li><a href="overzicht.html" class="actief">Producten</a></li>
      <li><a href="berichten.php">Berichten</a></li>
    </ul>
    <button class="nav__hamburger" aria-label="Menu openen"><span></span><span></span><span></span></button>
  </nav>
  <div class="nav__offscreen">
    <a href="../index.html">Home</a>
    <a href="overzicht.html">Producten</a>
    <a href="berichten.php">Berichten</a>
  </div>
  <div class="showcase">
    <div class="showcase__foto">
      <img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200&q=85" alt="Villa Côte d'Azur">
    </div>
    <div class="showcase__info">
      <p class="showcase__categorie">Vastgoed</p>
      <h1 class="showcase__naam">Villa<br><em>Côte d'Azur</em></h1>
      <p class="showcase__prijs">Vraagprijs: € 18.500.000 &mdash; Minimumbod: € 17.000.000</p>
      <p class="showcase__beschrijving">Prachtige villa direct aan de Middellandse Zee in Nice. Zes slaapkamers, privézwembad, eigen aanlegsteiger en een panoramisch terras met zeezicht. Volledig gemeubileerd en instapklaar.</p>
      <div class="showcase__specs">
        <div><p class="spec__label">Oppervlak</p><p class="spec__waarde">680 m²</p></div>
        <div><p class="spec__label">Slaapkamers</p><p class="spec__waarde">6</p></div>
        <div><p class="spec__label">Locatie</p><p class="spec__waarde">Nice, Frankrijk</p></div>
        <div><p class="spec__label">Bouwjaar</p><p class="spec__waarde">2017</p></div>
      </div>

      <?php if ($fout !== ''): ?>
        <p style="color:#c0392b; border:1px solid #c0392b; padding:12px 16px; margin-bottom:16px; font-size:14px;"><?= $fout ?></p>
      <?php endif; ?>

      <form class="formulier" action="bod_verwerken.php" method="POST">
        <input type="hidden" name="product" value="Villa Côte d'Azur">
        <input type="hidden" name="categorie" value="vastgoed">
        <input type="hidden" name="min_bod" value="17000000">
        <input type="hidden" name="terug" value="villa.php">
        <div class="formulier__rij">
          <div class="formulier__groep">
            <label class="formulier__label" for="naam">Naam</label>
            <input class="formulier__veld" type="text" id="naam" name="naam" placeholder="Uw naam" required>
          </div>
          <div class="formulier__groep">
            <label class="formulier__label" for="email">E-mail</label>
            <input class="formulier__veld" type="email" id="email" name="email" placeholder="u@domein.nl" required>
          </div>
        </div>
        <div class="formulier__groep">
          <label class="formulier__label" for="bericht">Bericht</label>
          <textarea class="formulier__veld" id="bericht" name="bericht" placeholder="Stel uw vraag of laat een opmerking achter..." required></textarea>
        </div>
        <div class="formulier__groep">
          <label class="formulier__label" for="bod">Uw bod (minimaal € 17.000.000)</label>
          <input class="formulier__veld" type="number" id="bod" name="bod" placeholder="17000000" min="17000000" required>
        </div>
        <button type="submit" class="knop" style="border:none;cursor:pointer;">Verstuur bod</button>
      </form>
    </div>
  </div>

  <section class="sectie sectie--donker">
    <div class="sectie__hoofd"><h2 class="sectie__titel">Andere producten</h2><a href="overzicht.html" class="sectie__link">Alle producten</a></div>
    <div class="product-grid">
      <a href="penthouse.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=85" alt="Penthouse Amsterdam Zuid"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Vastgoed</p><h3 class="product-kaart__naam">Penthouse Amsterdam Zuid</h3><p class="product-kaart__prijs">Vanaf € 9.200.000</p></div></a>
      <a href="bugatti.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1200&q=85" alt="Bugatti Chiron Super Sport"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Automobiel</p><h3 class="product-kaart__naam">Bugatti Chiron Super Sport</h3><p class="product-kaart__prijs">Vanaf € 3.200.000</p></div></a>
      <a href="rolex.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=1200&q=85" alt="Rolex Daytona Platina"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Horloge</p><h3 class="product-kaart__naam">Rolex Daytona Platina</h3><p class="product-kaart__prijs">Vanaf € 320.000</p></div></a>
    </div>
  </section>
  <footer class="footer">
    <div><p class="footer__logo">WEALTH CREATORS</p><p class="footer__omschrijving">De exclusieve marktplaats voor diegenen die alleen het allerbeste accepteren.</p></div>
    <div><p class="footer__koptekst">Navigatie</p><ul class="footer__lijst"><li><a href="../index.html">Home</a></li><li><a href="overzicht.html">Producten</a></li><li><a href="berichten.php">Berichten</a></li></ul></div>
    <div><p class="footer__koptekst">Categorieën</p><ul class="footer__lijst"><li><a href="overzicht.html">Automobiel</a></li><li><a href="overzicht.html">Vastgoed</a></li><li><a href="overzicht.html">Horloges</a></li><li><a href="overzicht.html">Boten</a></li></ul></div>
  </footer>
  <div class="footer__onder"><p class="footer__copy">2026 Wealth Creators. Alle rechten voorbehouden.</p><p class="footer__copy">Ontworpen door Team D1B</p></div>
  <script src="../js/main.js"></script>
</body>
</html>