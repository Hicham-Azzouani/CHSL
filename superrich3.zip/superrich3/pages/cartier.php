<?php
// Foutmelding ophalen als die er is
$fout = isset($_GET['fout']) ? htmlspecialchars(urldecode($_GET['fout'])) : '';
?>
<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cartier Diamanten Armband — Wealth Creators</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body class="paginatop">
  <nav class="nav">
    <a href="../index.html" class="nav__logo">WEALTH CREATORS</a>
    <ul class="nav__links">
      <li><a href="../index.html">Home</a></li>
      <li><a href="overzicht.html" class="actief">Producten</a></li>
      <li><a href="berichten.php">Berichten</a></li>
    </ul>
    <button class="nav__hamburger" aria-label="Menu openen"><span></span><span></span><span></span></button>
  </nav>
  <div class="nav__offscreen">
    <a href="../index.html">Home</a>
    <a href="overzicht.html">Producten</a>
    <a href="berichten.php">Berichten</a>
  </div>
  <div class="showcase">
    <div class="showcase__foto">
      <img src="https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=1200&q=85" alt="Cartier Diamanten Armband">
    </div>
    <div class="showcase__info">
      <p class="showcase__categorie">Sieraad</p>
      <h1 class="showcase__naam">Cartier<br><em>Diamanten Armband</em></h1>
      <p class="showcase__prijs">Vraagprijs: € 85.000 &mdash; Minimumbod: € 80.000</p>
      <p class="showcase__beschrijving">Een Cartier Panthère-armband bezet met 148 briljant geslepen diamanten van 12,4 karaat totaal. Uitgevoerd in 18-karaats witgoud. Inclusief Cartier-certificaat, originele doos en aankoopbewijs.</p>
      <div class="showcase__specs">
        <div><p class="spec__label">Materiaal</p><p class="spec__waarde">18k Witgoud</p></div>
        <div><p class="spec__label">Diamanten</p><p class="spec__waarde">148 stuks</p></div>
        <div><p class="spec__label">Totaal karaat</p><p class="spec__waarde">12,4 ct</p></div>
        <div><p class="spec__label">Staat</p><p class="spec__waarde">Nieuw</p></div>
      </div>

      <?php if ($fout !== ''): ?>
        <p style="color:#c0392b; border:1px solid #c0392b; padding:12px 16px; margin-bottom:16px; font-size:14px;"><?= $fout ?></p>
      <?php endif; ?>

      <form class="formulier" action="bod_verwerken.php" method="POST">
        <input type="hidden" name="product" value="Cartier Diamanten Armband">
        <input type="hidden" name="categorie" value="sieraad">
        <input type="hidden" name="min_bod" value="80000">
        <input type="hidden" name="terug" value="cartier.php">
        <div class="formulier__rij">
          <div class="formulier__groep">
            <label class="formulier__label" for="naam">Naam</label>
            <input class="formulier__veld" type="text" id="naam" name="naam" placeholder="Uw naam" required>
          </div>
          <div class="formulier__groep">
            <label class="formulier__label" for="email">E-mail</label>
            <input class="formulier__veld" type="email" id="email" name="email" placeholder="u@domein.nl" required>
          </div>
        </div>
        <div class="formulier__groep">
          <label class="formulier__label" for="bericht">Bericht</label>
          <textarea class="formulier__veld" id="bericht" name="bericht" placeholder="Stel uw vraag of laat een opmerking achter..." required></textarea>
        </div>
        <div class="formulier__groep">
          <label class="formulier__label" for="bod">Uw bod (minimaal € 80.000)</label>
          <input class="formulier__veld" type="number" id="bod" name="bod" placeholder="80000" min="80000" required>
        </div>
        <button type="submit" class="knop" style="border:none;cursor:pointer;">Verstuur bod</button>
      </form>
    </div>
  </div>

  <section class="sectie sectie--donker">
    <div class="sectie__hoofd"><h2 class="sectie__titel">Andere producten</h2><a href="overzicht.html" class="sectie__link">Alle producten</a></div>
    <div class="product-grid">
      <a href="rolex.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=1200&q=85" alt="Rolex Daytona Platina"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Horloge</p><h3 class="product-kaart__naam">Rolex Daytona Platina</h3><p class="product-kaart__prijs">Vanaf € 320.000</p></div></a>
      <a href="bugatti.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1200&q=85" alt="Bugatti Chiron Super Sport"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Automobiel</p><h3 class="product-kaart__naam">Bugatti Chiron Super Sport</h3><p class="product-kaart__prijs">Vanaf € 3.200.000</p></div></a>
      <a href="villa.php" class="product-kaart"><div class="product-kaart__foto"><img src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200&q=85" alt="Villa Côte d'Azur"></div><div class="product-kaart__info"><p class="product-kaart__categorie">Vastgoed</p><h3 class="product-kaart__naam">Villa Côte d'Azur</h3><p class="product-kaart__prijs">Vanaf € 18.500.000</p></div></a>
    </div>
  </section>
  <footer class="footer">
    <div><p class="footer__logo">WEALTH CREATORS</p><p class="footer__omschrijving">De exclusieve marktplaats voor diegenen die alleen het allerbeste accepteren.</p></div>
    <div><p class="footer__koptekst">Navigatie</p><ul class="footer__lijst"><li><a href="../index.html">Home</a></li><li><a href="overzicht.html">Producten</a></li><li><a href="berichten.php">Berichten</a></li></ul></div>
    <div><p class="footer__koptekst">Categorieën</p><ul class="footer__lijst"><li><a href="overzicht.html">Automobiel</a></li><li><a href="overzicht.html">Vastgoed</a></li><li><a href="overzicht.html">Horloges</a></li><li><a href="overzicht.html">Boten</a></li></ul></div>
  </footer>
  <div class="footer__onder"><p class="footer__copy">2026 Wealth Creators. Alle rechten voorbehouden.</p><p class="footer__copy">Ontworpen door Team D1B</p></div>
  <script src="../js/main.js"></script>
</body>
</html>